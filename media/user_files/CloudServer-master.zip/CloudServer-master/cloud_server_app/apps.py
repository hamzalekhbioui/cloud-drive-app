#cloud_server_app/apps.py
from django.apps import AppConfig

class FileDisplayAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cloud_server_app'
